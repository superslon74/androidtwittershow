package com.androidtwittershow.helper;

import android.content.Context;
import android.content.SharedPreferences;
/*
Created by superslon74@gmail.com on 17/05/18.
skype: superslon74
phone: +380935767412
 */
public class MyPreferenceManager {

    /*  constant keys */
    private static final String PREF_KEY = "login_prefs";
    private static final String USER_ID = "user_id";
    private static final String SCREEN_NAME = "screen_name";

    // manager instance
    private SharedPreferences sharedPreferences;

    public MyPreferenceManager(Context context) {
        //initialize preference
        sharedPreferences = context.getSharedPreferences(PREF_KEY, Context.MODE_PRIVATE);
    }

    /* method to save user id */
    public void saveUserId(Long userId) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong(USER_ID, userId);
        editor.apply();
    }

    /* return saved user id if exist else return */
    public Long getUserId() {
        return sharedPreferences.getLong(USER_ID, 0);
    }

    /* method to save user screen name */
    public void saveScreenName(String screenName) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(SCREEN_NAME, screenName);
        editor.apply();
    }

    /* return saved user screen name */
    public String getScreenName() {
        return sharedPreferences.getString(SCREEN_NAME, "");
    }
}
