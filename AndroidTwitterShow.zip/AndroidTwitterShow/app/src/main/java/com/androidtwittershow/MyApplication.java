package com.androidtwittershow;

import android.app.Application;
import android.util.Log;

import com.twitter.sdk.android.core.DefaultLogger;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterConfig;
/*
Created by superslon74@gmail.com on 17/05/18.
skype: superslon74
phone: +380935767412
 */
public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        //initiate Twitter config
        TwitterConfig config = new TwitterConfig.Builder(this)
                .logger(new DefaultLogger(Log.DEBUG))
                .twitterAuthConfig(new TwitterAuthConfig("gsZXxfbqVdqh8Eh6bcmcV83Ul", "C1l4XIroaGQ6oHoKrYQikMN1m21KzylzRsBKzHYGaX1B9NdovV"))//pass Twitter API Key and Secret
                .debug(true)
                .build();
        Twitter.initialize(config);
    }
}
