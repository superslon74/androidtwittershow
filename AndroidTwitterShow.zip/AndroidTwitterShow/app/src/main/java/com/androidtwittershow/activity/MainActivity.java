package com.androidtwittershow.activity;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import com.androidtwittershow.adapter.TabViewPagerAdapter;
import com.androidtwittershow.tabls.CollectionTimelineFragment;
import com.androidtwittershow.tabls.SearchTimelineFragment;
import com.androidtwittershow.tabls.UserTimelineFragment;

/*
Created by superslon74@gmail.com on 17/05/18.
skype: superslon74
phone: +380935767412
 */
public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }

    /* init views including finding id of views and setting tab with fragments */
    private void initViews() {
        viewPager = findViewById(R.id.twitter_view_pager);
        setupViewPager();

        tabLayout = findViewById(R.id.twitter_tab);
        tabLayout.setupWithViewPager(viewPager);//setting tab over viewpager
    }

    /* set fragment to View pager */
    private void setupViewPager() {

        //get tab array from string.xml
        String[] tabArray = getResources().getStringArray(R.array.tab_items);

        TabViewPagerAdapter adapter = new TabViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(UserTimelineFragment.newInstance(), tabArray[0]);
        adapter.addFrag(SearchTimelineFragment.newInstance(), tabArray[1]);
        adapter.addFrag(CollectionTimelineFragment.newInstance(), tabArray[2]);
        viewPager.setAdapter(adapter);
    }
}
